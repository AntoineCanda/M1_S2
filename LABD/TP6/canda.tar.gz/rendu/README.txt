CANDA Antoine

readme

Exercice 1 est fait.


Exercice 2 est fait partiellement :

Question 1, 2, 3 et 4 sont faites.

Question 3 : le tri selon les noms des colonnes ne marchent pas.



Exercice 3 : partiellement fait

Question 1 : je n'ai pas réussi à faire la question ? Soucis avec xsltproc sur ma machine ?

Question 2 et 3 : fait/tentative sans test réel vu que la question 1 ne marche pas. 


