CANDA Antoine

readme
Ne sont présent que les fichiers que j'ai modifié pour les questions du tp.

Exercice 1 est fait.

Voir catalogue.xsl

Exercice 2 est fait.

Question 1, 2, 3 et 4 sont faites.

Question 3 : le tri selon les noms des colonnes ne marchent pas.

Voir catalogue_*


Exercice 3 : partiellement fait (question 1 à 3)


Voir panier_* et catalogue_*


