TP 4 LABD
CANDA Antoine

Exercice 1 : fait: voir championnat.xml et championnat.xsd

Exercice 2 : fait: voir examen1.xsd et examen2.xsd

Exercice 3 : fait: voir a.xsd b.xsd et a.xml

Exercice 4 : fait: voir exercice4.txt, personnes.xml et personnes.xsd

Exercice 5 : fait voir livret-famille.xsd. 
J'ai mis pour le nombre d'enfants une limite � 70 car c'est plus que le record assez peu cr�dible d'enfant d'une m�me femme...
J'aurais aussi pu mettre unbounded mais ce n'est pas tr�s r�aliste et je n'ai pas trouv� d'informations indiquant un nombre maximal pr�vu de base. 


