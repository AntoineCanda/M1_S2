TP DS1 bonus
CANDA Antoine

Exercice 1 : fait 

Fichier a1.xml et a2.xml qui repr�sente les deux arbres.
Fichiers dtd1.dtd, dtd2.dtd et dtd3.dtd qui repr�sente les diff�rents fichiers contenant les r�gles dtd pour les arbres.

Le fichier dtd1.dtd valide a1.xml mais pas a2.xml.
Le fichier dtd2.dtd valide a2.xml mais pas a1.xml.
Le fichier dtd3.dtd valide a1.xml et a2.xml.


Exercice 2 : fait 

La r�ponse est 4. 
java -jar labd.jar a.xml 
Il n'y avait rien � faire ici si ce n'est cr�er le fichier...

Exercice 3 : fait 

Pour la question 5 je dirais que c'�tait les r�f�rences � l'espace de nom qui est non faite : en les ajoutant avec le reste du contenu �a marche. 

Voir les deux fichiers reseau.xml et reseau-sujet.xsd
		
Exercice 4 : fait 

Voir fichier exercice4.txt. J'ai en revanche suivi le ds en ne tenant pas compte de l'espace de nom et en retirant du coup les r�f�rences associ�s du fichier.

 