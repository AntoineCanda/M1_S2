CANDA Antoine 
TP8 de LABD

Avancement :

Q1 : faite voir expression.xq test possible avec expression1.xq 
Q2 : faite voir expression.xq test possible avec expression2.xq
Q3 : faite voir expression.xq test possible avec expression3.xq
Q4 : echec lors des tentatives je me basais globalement sur la base fournie par q3 sans succ�s. 