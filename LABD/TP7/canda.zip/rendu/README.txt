CANDA Antoine
TP 7 

Exercice 1 : fait

Voir dossier exercice1

README.txt

Exercice 2 : fait

Voir dossier exercice2

maisons.xql

résultat obtenu par saxon mis sur un fichier 

Exercice 3 : fait

Voir dossier exercice3

q1.xml => resultat obtenu par q1.xql avec saxon mis sur un fichier 

q2.xml => resultat obtenu par q2.xql avec saxon mis sur un fichier 

q3.xml => resultat obtenu par q3.xml avec saxon mis sur un fichier 

q4.xml => resultat obtenu par q4.xql avec saxon mis sur un fichier. J'ai utilisé en autre la fonction round-half-to-even pour l'arrondi à 1 chiffre apres virgule et substring pour les prix (retiré $) notamment. 