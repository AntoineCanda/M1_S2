TP 5 
CANDA Antoine 


Exercice 1 : 

fait entièrement.

voir:
- q1.xsl voir q1.html 
- q2.xsl voir q2.xml
- q3.xsl voir q3.html 
- q4.xsl voir q4.xml
- q5.xsl voir q5.xml
- q6.xsl voir q6.xml

Exercice 2 :
 
fait entièrement.

voir:

- nbOeuvre.xsl voir nbOeuvre.xml 
- fusion.xsl voir fusion.xml
- artiste-avec-clef.xsl et artiste-avec-clef.xml
- oeuvre-clef-externe.xsl et oeuvre-clef-externe.xml
- catalogue.xsl et catalogue-artistes.xml 