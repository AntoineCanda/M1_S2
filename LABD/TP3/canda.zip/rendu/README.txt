CANDA Antoine 
TP3 de LABD

Exercice 1 : fait voir exercice1.txt, exo1.xml et exo1.xsd

Exercice 2 : fait voir okaz.xsd

Exercice 3 : fait voir expression.xsd

Exercice 4 : fait voir championnat.xsd 