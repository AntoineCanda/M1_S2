package univlille.m1info.abd.tp3;

import univlille.m1info.abd.phys.PhysicalOperator;
import univlille.m1info.abd.ra.RAQuery;
import univlille.m1info.abd.tp2.SimpleSGBD;

public class TP3 {
	
	/** Creates an operator that allows to (efficiently) execute the given operation on the given database. */
	public PhysicalOperator getOperator(RAQuery query, SimpleSGBD sgbd) {
		throw new UnsupportedOperationException("not yet implemented");
	}
}
