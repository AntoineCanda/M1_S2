CANDA Antoine

ABD - rendu 1 le 16 mars 2017

Pour tester, il suffit de modifier la classe App pr�sent dans le package main. 
Il suffit de mettre la RAQuery voulu et modifier en cons�quence la relation dans le sgbd. 

J'ai gard� la version avec le design pattern visitor (tp 4) qui m'apparait comme la plus simple et compl�te pour r�pondre � la premi�re partie du projet. 

Elle se trouve dans le dossier src package : univlille.m1info.abd.tp4.TreeQueryCreator.
Les operators utilisaient se trouve dans le package  univlille.m1info.abd.tp3.*
