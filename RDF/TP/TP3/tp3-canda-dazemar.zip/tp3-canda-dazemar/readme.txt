TP3 RDF 
CANDA Antoine 
DAZEMAR Arthur

Dans l'archive sont pr�sent le compte rendu, ce fichier ainsi que 5 images png.
Je suis d�sol� de fournir ces images dans ce dossier et non dans le rapport mais suite � un caprice de notre editeur Latex, il m'a �t� impossible de les upload�s pour les ajouter au rapport.
La deadline approchant j'ai pr�f�r� les joindre en annexe plut�t que de ne pas les rendre.

Ces images correspondent � la s�paration en deux parties des histogrammes conjoints des parties repr�sentants les disques du fond pour les 5 textures.

Ce TP nous ayant pos�s pas mal de difficult�s et d'apr�s ce que j'ai pu voir chez d'autres groupes nous ne sommes pas les seuls, on aimerait savoir si il �tait possible d'avoir une correction 
rapide du/des tp pour pouvoir comprendre nos erreurs et pr�par�s plus sereinement les examens de fin de semestre ?

Merci de votre attention.